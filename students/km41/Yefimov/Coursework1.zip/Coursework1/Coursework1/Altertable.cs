﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
namespace Coursework1
{
    public partial class Altertable : Form
    {
        string cbo = "0";
        string cbm = "0";
        bool buttonclicked = false;
        public Altertable()
        {
            InitializeComponent();
            tbname.Text = Form2.namestring;
            tbvideo.Text = Form2.namevideo;
            tbvmemory.Text = Form2.vmemvolume;
            tbram.Text = Form2.ramvolume;
            tbhdd.Text = Form2.hddvolume;
            tbmoni.Text = Form2.monidiagonal;
            cbodrive.Checked = Form2.optibool;
            cbmoni.Checked = Form2.monibool;
        }

        private void Changebutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;
            if (Program.number.IsMatch(tbvmemory.Text.Trim()) && Program.number.IsMatch(tbram.Text.Trim())
                && Program.number.IsMatch(tbhdd.Text.Trim()) && Program.number.IsMatch(tbmoni.Text.Trim()))
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to update?", "Computers", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                
                        try
                        {
                            //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                            //   Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                            //SqlConnection sqlcon = new SqlConnection(connection);
                            //sqlcon.Open();
                            Program.ConnectDb connect1 = new Program.ConnectDb();
                            connect1.assignConnect(Program.user_name, Program.pass_word);
                            connect1.myConnection.Open();
                            if (cbmoni.Checked == true)
                                cbm = "1";
                            else
                                cbm = "0";
                            if (cbodrive.Checked == true)
                                cbo = "1";
                            else
                                cbo = "0";
                            string cmd = "UPDATE dbo.Admin_computers SET name='" + tbname.Text + "', video='" + tbvideo.Text +
                                "', videogb=" + tbvmemory.Text + ", memory=" + tbram.Text + ", hdd =" + tbhdd.Text + ", optidrive =" +
                                cbo + ", monit = " + cbm + ", moninches = " + tbmoni.Text + " WHERE id=" + Form2.id;
                            SqlCommand command = new SqlCommand(cmd, connect1.myConnection);
                            command.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                }
                else if (dialogResult == DialogResult.No)
                {
                }
                Form2 f2 = new Form2();
                this.Hide();
                f2.Show();
            }
            else
            {
                MessageBox.Show("Video memory, RAM, HDD volume and monitor diagonal should be numbers!");
            }
        }

        private void Altertable_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (buttonclicked == false)
            {
                Form2 f2 = new Form2();
                f2.Show();
            }
        }

        private void addbutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;
            if (Program.number.IsMatch(tbvmemory.Text.Trim()) && Program.number.IsMatch(tbram.Text.Trim())
                && Program.number.IsMatch(tbhdd.Text.Trim()) && Program.number.IsMatch(tbmoni.Text.Trim()))
            {
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to add?", "Computers", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                    //   Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                    //SqlConnection sqlcon = new SqlConnection(connection);
                    //sqlcon.Open();
                    Program.ConnectDb connect1 = new Program.ConnectDb();
                    connect1.assignConnect(Program.user_name, Program.pass_word);
                    connect1.myConnection.Open();
                    if (cbmoni.Checked == true)
                        cbm = "1";
                    else
                        cbm = "0";
                    if (cbodrive.Checked == true)
                        cbo = "1";
                    else
                        cbo = "0";
                    string cmd = "INSERT INTO dbo.Admin_computers (name, video, videogb, memory, hdd, optidrive, monit, moninches)" +
                        " values ('" + tbname.Text + "', '" + tbvideo.Text +"', " + tbvmemory.Text + ", " +
                        tbram.Text + ", " + tbhdd.Text + ", " + cbo + ",  " + cbm + ", " + tbmoni.Text + ")";
                    SqlCommand command = new SqlCommand(cmd, connect1.myConnection);
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
            else if (dialogResult == DialogResult.No)
            {
            }

            Form2 f2 = new Form2();
            this.Hide();
            f2.Show();
            }
            else
            {
                MessageBox.Show("Video memory, RAM, HDD volume and monitor diagonal should be numbers!");
            }
        }

        private void clearbutton_Click(object sender, EventArgs e)
        {
            tbname.Text = "";
            tbvideo.Text = "";
            tbvmemory.Text = "";
            tbram.Text = "";
            tbhdd.Text = "";
            tbmoni.Text = "";
            cbodrive.Checked = false;
            cbmoni.Checked = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            buttonclicked = true;

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete?", "Computers", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                //       Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                //SqlConnection sqlcon = new SqlConnection(connection);
                //sqlcon.Open();
                Program.ConnectDb connect1 = new Program.ConnectDb();
                connect1.assignConnect(Program.user_name, Program.pass_word);
                connect1.myConnection.Open();
                string cmd = "DELETE FROM dbo.Admin_computers WHERE id=" + Form2.id;
                SqlCommand command = new SqlCommand(cmd, connect1.myConnection);
                command.ExecuteNonQuery();
            }
            else if (dialogResult == DialogResult.No)
            {
            }

            Form2 f2 = new Form2();
            this.Hide();
            f2.Show();
        }

        private void closebutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to close?", "Computers", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Form2 f2 = new Form2();
                this.Hide();
                f2.Show();
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }
    }
}

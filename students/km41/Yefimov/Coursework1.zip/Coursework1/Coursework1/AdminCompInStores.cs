﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Coursework1
{
    public partial class AdminCompInStores : Form
    {
        public AdminCompInStores()
        {
            InitializeComponent();
        }
        public static int compid = 0;
        public static int storeid = 0;
        public static decimal price = 0;
        public static string comment = "";
        public static int id;

        private void AdminCompInStores_Load(object sender, EventArgs e)
        {
            //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
            //        Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
            //SqlConnection sqlcon = new SqlConnection(connection);
            //sqlcon.Open();
            Program.ConnectDb connect1 = new Program.ConnectDb();
            connect1.assignConnect(Program.user_name, Program.pass_word);
            connect1.myConnection.Open();
            DataTable dtbl = new DataTable();
            using (var command = new SqlCommand("SELECT * FROM dbo.Admin_ComputerInStores", connect1.myConnection))
                dtbl.Load(command.ExecuteReader());
            dgvcis.AllowUserToAddRows = false;
            dgvcis.DataSource = dtbl;
            dgvcis.Columns[dgvcis.ColumnCount - 1].Visible = false;
            dgvcis.Columns[dgvcis.ColumnCount - 2].Visible = false;

        }

        private void dgvcis_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow selectedRow = dgvcis.Rows[e.RowIndex];
            id = Convert.ToInt32(selectedRow.Cells[0].Value);
            price = Convert.ToDecimal(selectedRow.Cells[3].Value);
            comment = selectedRow.Cells[4].Value.ToString();
            compid = Convert.ToInt32(selectedRow.Cells[5].Value);
            storeid = Convert.ToInt32(selectedRow.Cells[6].Value);
            AlterCompInstores acs = new AlterCompInstores();
            acs.ShowDialog();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

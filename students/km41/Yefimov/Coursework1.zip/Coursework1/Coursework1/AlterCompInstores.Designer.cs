﻿namespace Coursework1
{
    partial class AlterCompInstores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.combocomp = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.combostore = new System.Windows.Forms.ComboBox();
            this.clearbutton = new System.Windows.Forms.Button();
            this.closebutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.addbutton = new System.Windows.Forms.Button();
            this.Changebutton = new System.Windows.Forms.Button();
            this.tbprice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rtbcomment = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // combocomp
            // 
            this.combocomp.FormattingEnabled = true;
            this.combocomp.Location = new System.Drawing.Point(70, 9);
            this.combocomp.Name = "combocomp";
            this.combocomp.Size = new System.Drawing.Size(609, 21);
            this.combocomp.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Computer";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Store";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Price";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // combostore
            // 
            this.combostore.FormattingEnabled = true;
            this.combostore.Location = new System.Drawing.Point(70, 37);
            this.combostore.Name = "combostore";
            this.combostore.Size = new System.Drawing.Size(609, 21);
            this.combostore.TabIndex = 4;
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(725, 124);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(75, 36);
            this.clearbutton.TabIndex = 25;
            this.clearbutton.Text = "Clear comment";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // closebutton
            // 
            this.closebutton.Location = new System.Drawing.Point(725, 96);
            this.closebutton.Name = "closebutton";
            this.closebutton.Size = new System.Drawing.Size(75, 22);
            this.closebutton.TabIndex = 24;
            this.closebutton.Text = "Close ";
            this.closebutton.UseVisualStyleBackColor = true;
            this.closebutton.Click += new System.EventHandler(this.closebutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.Location = new System.Drawing.Point(725, 67);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(75, 23);
            this.Deletebutton.TabIndex = 23;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = true;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // addbutton
            // 
            this.addbutton.Location = new System.Drawing.Point(725, 38);
            this.addbutton.Name = "addbutton";
            this.addbutton.Size = new System.Drawing.Size(75, 23);
            this.addbutton.TabIndex = 22;
            this.addbutton.Text = "Add";
            this.addbutton.UseVisualStyleBackColor = true;
            this.addbutton.Click += new System.EventHandler(this.addbutton_Click);
            // 
            // Changebutton
            // 
            this.Changebutton.Location = new System.Drawing.Point(725, 7);
            this.Changebutton.Name = "Changebutton";
            this.Changebutton.Size = new System.Drawing.Size(75, 23);
            this.Changebutton.TabIndex = 21;
            this.Changebutton.Text = "Change";
            this.Changebutton.UseVisualStyleBackColor = true;
            this.Changebutton.Click += new System.EventHandler(this.Changebutton_Click);
            // 
            // tbprice
            // 
            this.tbprice.Location = new System.Drawing.Point(70, 65);
            this.tbprice.Name = "tbprice";
            this.tbprice.Size = new System.Drawing.Size(609, 20);
            this.tbprice.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 28;
            this.label4.Text = "Comment";
            // 
            // rtbcomment
            // 
            this.rtbcomment.Location = new System.Drawing.Point(70, 98);
            this.rtbcomment.Name = "rtbcomment";
            this.rtbcomment.Size = new System.Drawing.Size(609, 96);
            this.rtbcomment.TabIndex = 29;
            this.rtbcomment.Text = "";
            // 
            // AlterCompInstores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 198);
            this.Controls.Add(this.rtbcomment);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbprice);
            this.Controls.Add(this.clearbutton);
            this.Controls.Add(this.closebutton);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.addbutton);
            this.Controls.Add(this.Changebutton);
            this.Controls.Add(this.combostore);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.combocomp);
            this.Name = "AlterCompInstores";
            this.Text = "AlterCompInstores";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AlterCompInstores_FormClosing);
            this.Load += new System.EventHandler(this.AlterCompInstores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combocomp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox combostore;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Button closebutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button addbutton;
        private System.Windows.Forms.Button Changebutton;
        private System.Windows.Forms.TextBox tbprice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox rtbcomment;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Coursework1
{
    public partial class AlterStores : Form
    {
        public AlterStores()
        {
            InitializeComponent();
            tbstorname.Text = AdminStores.storename;
            tbadres.Text = AdminStores.storeadres;
            tbemail.Text = AdminStores.storemail;

        }
        bool buttonclicked = false;

        private void Changebutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to update?", "Stores", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try { 
                //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                //       Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                //SqlConnection sqlcon = new SqlConnection(connection);
                //sqlcon.Open();
                Program.ConnectDb connect1 = new Program.ConnectDb();
                connect1.assignConnect(Program.user_name, Program.pass_word);
                connect1.myConnection.Open();
                string cmd = "UPDATE dbo.Admin_Stores SET name='" + tbstorname.Text + "', address='" + tbadres.Text +
                    "', email='" + tbemail.Text + "' WHERE ID="+AdminStores.id;
                SqlCommand command = new SqlCommand(cmd, connect1.myConnection);
                command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }

            AdminStores ast = new AdminStores();
            this.Hide();
            ast.Show();
        }

        private void addbutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to add?", "Stores", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try { 
                //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                //       Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                //SqlConnection sqlcon = new SqlConnection(connection);
                //sqlcon.Open();
                Program.ConnectDb connect1 = new Program.ConnectDb();
                connect1.assignConnect(Program.user_name, Program.pass_word);
                connect1.myConnection.Open();
                string cmd = "INSERT INTO dbo.Admin_Stores (name, address, email) values ('" + tbstorname.Text 
                    + "', '" + tbadres.Text + "', '" + tbemail.Text + "')";
                SqlCommand command = new SqlCommand(cmd, connect1.myConnection);
                command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }

            AdminStores ast = new AdminStores();
            this.Hide();
            ast.Show();
        }

        private void deletebutton_Click(object sender, EventArgs e)
        {
             buttonclicked = true;

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete?", "Computers", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try { 
                //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                //       Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                //SqlConnection sqlcon = new SqlConnection(connection);
                //sqlcon.Open();
                Program.ConnectDb connect1 = new Program.ConnectDb();
                connect1.assignConnect(Program.user_name, Program.pass_word);
                connect1.myConnection.Open();
                string cmd = "DELETE FROM dbo.Admin_Stores WHERE id=" + AdminStores.id;
                SqlCommand command = new SqlCommand(cmd, connect1.myConnection);
                command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
            }
            AdminStores ast = new AdminStores();
            this.Hide();
            ast.Show();

        }

        private void closebutton_Click(object sender, EventArgs e)
        {
            buttonclicked = true;
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to close?", "Computers", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                AdminStores ast = new AdminStores();
                this.Hide();
                ast.Show();
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void clearbutton_Click(object sender, EventArgs e)
        {
            tbstorname.Text = "";
            tbadres.Text = "";
            tbemail.Text = "";
        }

        private void AlterStores_FormClosing(object sender, FormClosingEventArgs e)
        {

            if (buttonclicked == false)
            {
                AdminStores ast = new AdminStores();
                ast.Show();
            }
        }

        //private void label3_Click(object sender, EventArgs e)
        //{

        //}
    }
}

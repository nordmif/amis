﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Coursework1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        public static DataTable dt1 = new DataTable();
        public static string namestring = "";
        public static string namevideo = "";
        public static string vmemvolume = "";
        public static string ramvolume = "";
        public static string hddvolume = "";
        public static string monidiagonal = "";
        public static int id;
        public static bool optibool = false;
        public static bool monibool = false;
        private void Form2_Load(object sender, EventArgs e)
        {
            //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
            //        Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
            //SqlConnection sqlcon = new SqlConnection(connection);
            //sqlcon.Open();
            Program.ConnectDb connect1 = new Program.ConnectDb();
            connect1.assignConnect(Program.user_name, Program.pass_word);
            connect1.myConnection.Open();
            DataTable dtbl = new DataTable();
            using (var command = new SqlCommand("SELECT * FROM dbo.Admin_computers", connect1.myConnection))
                dtbl.Load(command.ExecuteReader());

            //dtbl.Rows[dtbl.Rows.Count].Delete();
            //int a = dtbl.Rows.Count;
            dgvtable.AllowUserToAddRows = false;
            dgvtable.DataSource = dtbl;
            //for (int i = 0; i < dgvtable.Columns.Count; i++)
            //    dt1.Columns.Add(dgvtable.Columns[i].Name);
        }
        

        private void dgvtable_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            //dt1.Rows.Add(dgvtable.CurrentRow);
            //s1 = dgvtable.Rows
            
        }

        private void dgvtable_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            
        }

        private void dgvtable_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow selectedRow = dgvtable.Rows[e.RowIndex];
            id = Convert.ToInt32(selectedRow.Cells[0].Value);
            namestring = selectedRow.Cells[1].Value.ToString();
            namevideo = selectedRow.Cells[2].Value.ToString();
            vmemvolume = selectedRow.Cells[3].Value.ToString();
            ramvolume = selectedRow.Cells[4].Value.ToString();
            hddvolume = selectedRow.Cells[5].Value.ToString();
            monidiagonal = selectedRow.Cells[8].Value.ToString();
            optibool = Convert.ToBoolean(selectedRow.Cells[6].Value);
            monibool = Convert.ToBoolean(selectedRow.Cells[7].Value);
            Altertable at = new Altertable();
            at.ShowDialog();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Coursework1
{
    public partial class AdminStores : Form
    {
        public AdminStores()
        {
            InitializeComponent();
        }
        public static string storename = "";
        public static string storeadres = "";
        public static string storemail = "";
        public static int id;
        private void AdminStores_Load(object sender, EventArgs e)
        {
            //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
            //        Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
            //SqlConnection sqlcon = new SqlConnection(connection);
            //sqlcon.Open();
            Program.ConnectDb connect1 = new Program.ConnectDb();
            connect1.assignConnect(Program.user_name, Program.pass_word);
            connect1.myConnection.Open();
            DataTable dtbl = new DataTable();
            using (var command = new SqlCommand("SELECT * FROM dbo.Admin_Stores", connect1.myConnection))
                dtbl.Load(command.ExecuteReader());
            dgvStores.AllowUserToAddRows = false;
            dgvStores.DataSource = dtbl;
        }

        private void dgvStores_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            DataGridViewRow selectedRow = dgvStores.Rows[e.RowIndex];
            id = Convert.ToInt32(selectedRow.Cells[0].Value);
            storename = selectedRow.Cells[1].Value.ToString();
            storeadres = selectedRow.Cells[2].Value.ToString();
            storemail = selectedRow.Cells[3].Value.ToString();
            AlterStores ast = new AlterStores();
            ast.ShowDialog();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Coursework1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] likesandequals = new string[] { "like", "notlike", "equal", "notequal" };
        string[] likes = new string[] { "like", "notlike" };
        string[] numbig = new string[] { "less", "great", "equal", "notequal" };
        string[] numlittle = new string[] { "less", "great", "between" };

        public string searchInStores;
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "courseworkDataSet.View_computers". При необходимости она может быть перемещена или удалена.
            //this.view_computersTableAdapter.Fill(this.courseworkDataSet.View_computers);
                    //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                    //        Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                    //SqlConnection sqlcon = new SqlConnection(connection);
                    //sqlcon.Open();

            Program.ConnectDb connect1 = new Program.ConnectDb();
            connect1.assignConnect(Program.user_name, Program.pass_word);
            connect1.myConnection.Open();
            DataTable dtbl = new DataTable();
            string cmd = "SELECT * FROM dbo.SearchComputersAndStores ('', 'all', '', 'all',0, 'all', " +
                "0, 'all', 0, 'all', '', 'all', '', 'all',  0, 0, 'all')";
            using (var command = new SqlCommand(cmd, connect1.myConnection))
                dtbl.Load(command.ExecuteReader());
            dgvcomps.DataSource = dtbl;
            dgvcomps.AllowUserToAddRows = false;
            dgvcomps.Columns[1].Width = 600;
            DataTable dtbl1 = new DataTable();
            searchInStores = "SELECT id, computer_id, price, comment, Store FROM dbo.SearchInStores ('', 'all', '', 'all',  0, 0, 'all')";
            string cmd1 = searchInStores;
            using (var command = new SqlCommand(cmd1, connect1.myConnection))
                dtbl1.Load(command.ExecuteReader());
            dgvstores.DataSource = dtbl1;
            dgvstores.AllowUserToAddRows = false;
            dgvcomps.Columns[0].Visible = false;
            dgvstores.Columns[0].Visible = false;
            dgvstores.Columns[1].Visible = false;
            dgvstores.Columns[2].Width = 100;
            dgvstores.Columns[3].Width = 150;
            dgvstores.Columns[4].Width = 500;
            combocomp.DataSource = likesandequals.ToArray();
            combovideo.DataSource = likesandequals.ToArray();
            combostore.DataSource = likesandequals.ToArray();
            comboadres.DataSource = likes.ToArray();
            comboprice.DataSource = numlittle.ToArray();
            combomem.DataSource = numbig.ToArray();
            combovmem.DataSource = numbig.ToArray();
            combohdd.DataSource = numbig.ToArray();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbcompname_CheckedChanged(object sender, EventArgs e)
        {
            if (cbcompname.Checked == true)
            {
                combocomp.Visible = true;
                tbcomp.Visible = true;
            }
            else
            {
                combocomp.Visible = false;
                tbcomp.Visible = false;
            }
        }

        private void cbvidname_CheckedChanged(object sender, EventArgs e)
        {
            if (cbvidname.Checked == true)
            {
                combovideo.Visible = true;
                tbvideo.Visible = true;
            }
            else
            {
                combovideo.Visible = false;
                tbvideo.Visible = false;
            }
        }

        private void cbvidmem_CheckedChanged(object sender, EventArgs e)
        {
            if (cbvidmem.Checked == true)
            {
                combovmem.Visible = true;
                tbvmem.Visible = true;
            }
            else
            {
                combovmem.Visible = false;
                tbvmem.Visible = false;
            }
        }

        private void cbmemory_CheckedChanged(object sender, EventArgs e)
        {
            if (cbmemory.Checked == true)
            {
                combomem.Visible = true;
                tbmem.Visible = true;
            }
            else
            {
                combomem.Visible = false;
                tbmem.Visible = false;
            }
        }

        private void cbhdd_CheckedChanged(object sender, EventArgs e)
        {
            if (cbhdd.Checked == true)
            {
                combohdd.Visible = true;
                tbhdd.Visible = true;
            }
            else
            {
                combohdd.Visible = false;
                tbhdd.Visible = false;
            }
        }

        private void cbstorename_CheckedChanged(object sender, EventArgs e)
        {
            if (cbstorename.Checked == true)
            {
                combostore.Visible = true;
                tbstore.Visible = true;
            }
            else
            {
                combostore.Visible = false;
                tbstore.Visible = false;
            }
        }

        private void cbstoreaddress_CheckedChanged(object sender, EventArgs e)
        {
            if (cbstoreaddress.Checked == true)
            {
                comboadres.Visible = true;
                tbadres.Visible = true;
            }
            else
            {
                comboadres.Visible = false;
                tbadres.Visible = false;
            }

        }

        private void cbprice_CheckedChanged(object sender, EventArgs e)
        {
            if (cbprice.Checked == true)
            {
                comboprice.Visible = true;
                tbprice1.Visible = true;
            }
            else
            {
                comboprice.Visible = false;
                tbprice1.Visible = false;
                tbprice2.Visible = false;
            }
        }

        private void srchbutton_Click(object sender, EventArgs e)
        {
            //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
            //        Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
            //SqlConnection sqlcon = new SqlConnection(connection);
            //sqlcon.Open();
            Program.ConnectDb connect1 = new Program.ConnectDb();
            connect1.assignConnect(Program.user_name, Program.pass_word);
            connect1.myConnection.Open();

            DataTable dtbl = new DataTable();
            string comp1, comp2, comp3, vid1, vid2, vid3, vmem1, vmem2, vmem3, mem1, mem2, mem3, hdd1, hdd2, hdd3,
                store1, store2, store3, address1, address2, address3, price1, price2, price3, price2a;
            if (cbcompname.Checked == true)
            {
                comp1 = combocomp.SelectedItem.ToString();
                comp2 = tbcomp.Text.Trim();
                comp3 = "'"+comp2+"', '"+comp1+"'";
            }
            else
                comp3 = "'', 'all'";
            if (cbvidname.Checked == true)
            {
                vid1 = combovideo.SelectedItem.ToString();
                vid2 = tbvideo.Text.Trim();
                vid3 = "'" + vid2 + "', '" + vid1 + "'";
            }
            else
                vid3 = "'', 'all'";
            if (cbvidmem.Checked == true)
            {
                vmem1 = combovmem.SelectedItem.ToString();
                vmem2 = tbvmem.Text.Trim();
                vmem3 = "" + vmem2 + ", '" + vmem1 + "'";
            }
            else
                vmem3 = "0, 'all'";
            if (cbmemory.Checked == true)
            {
                mem1 = combomem.SelectedItem.ToString();
                mem2 = tbmem.Text.Trim();
                mem3 = "" + mem2 + ", '" + mem1 + "'";
            }
            else
                mem3 = "0, 'all'";
            if (cbhdd.Checked == true)
            {
                hdd1 = combohdd.SelectedItem.ToString();
                hdd2 = tbhdd.Text.Trim();
                hdd3 = "" + hdd2 + ", '" + hdd1 + "'";
            }
            else
                hdd3 = "0, 'all'";
            if (cbstorename.Checked == true)
            {
                store1 = combostore.SelectedItem.ToString();
                store2 = tbstore.Text.Trim();
                store3 = "'" + store2 + "', '" + store1 + "'";
            }
            else
                store3 = "'', 'all'";
            if (cbstoreaddress.Checked == true)
            {
                address1 = comboadres.SelectedItem.ToString();
                address2 = tbadres.Text.Trim();
                address3 = "'" + address2 + "', '" + address1 + "'";
            }
            else
                address3 = "'', 'all'";
            if (cbprice.Checked == true)
            {
                price1 = comboprice.SelectedItem.ToString();
                price2 = tbprice1.Text.Trim();
                price2a = tbprice2.Text.Trim();
                if (price2a == "")
                    price2a = "0";
                price3 = "" + price2 + ", " + price2a + ", '" + price1 +"'";
            }
            else
                price3 = "0, 0, 'all'";
            string cmd = "SELECT * FROM dbo.SearchComputersAndStores ("+comp3+", "+vid3+", "+vmem3+", " +mem3+","+hdd3+
                ","+store3+","+address3+ ","+price3+")";
            string cmd_forStores = "SELECT [id] FROM dbo.SearchComputersAndStores (" + comp3 + ", " + vid3 + ", " + vmem3 + ", " + mem3 + "," + hdd3 +
                "," + store3 + "," + address3 + "," + price3 + ")";
            using (var command = new SqlCommand(cmd, connect1.myConnection))
                dtbl.Load(command.ExecuteReader());
            dgvcomps.DataSource = dtbl;
            dgvcomps.AllowUserToAddRows = false;
            //dgvcomps.Columns[1].Width = 700;
            searchInStores = "SELECT id, computer_id, price, comment, Store FROM dbo.SearchInStores (" + store3 + "," + address3 + "," + price3 + ")" ;
            string cmd2 = searchInStores;
                //+ " WHERE computer_id IN ("+cmd_forStores + ")";
            DataTable dtbl2 = new DataTable();
            using (var command = new SqlCommand(cmd2, connect1.myConnection))
                dtbl2.Load(command.ExecuteReader());
            dgvstores.DataSource = dtbl2;
            dgvstores.AllowUserToAddRows = false;
            
            
        }

        private void comboprice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboprice.SelectedIndex==2)
                tbprice2.Visible = true;
            else
                tbprice2.Visible = false;
        }

        private void dgvcomps_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dgvcomps_RowLeave(object sender, DataGridViewCellEventArgs e)
        {
           
            
        }

        private void dgvcomps_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvcomps.SelectedRows.Count > 0)
            {
                //int id = Convert.ToInt32(gridView.SelectedRows[0].Cells["ColummID"].Value.ToString());
                //l_debug.Text = dgvcomps.SelectedRows[0].Cells["Id"].Value.ToString();
                        //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                        //        Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                        //SqlConnection sqlcon = new SqlConnection(connection);
                        //sqlcon.Open();
                Program.ConnectDb connect1 = new Program.ConnectDb();
                connect1.assignConnect(Program.user_name, Program.pass_word);
                connect1.myConnection.Open();

                DataTable dtbl1 = new DataTable();
                string cmd1 = searchInStores + " where computer_id=" + dgvcomps.SelectedRows[0].Cells["Id"].Value.ToString();
                using (var command = new SqlCommand(cmd1, connect1.myConnection))
                    dtbl1.Load(command.ExecuteReader());
                dgvstores.DataSource = dtbl1;
                dgvstores.AllowUserToAddRows = false;
                
            }
        }

        private void dgvcomps_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvcomps.SelectedCells.Count > 0)
            {
                //l_debug2.Text = dgvcomps.CurrentRow.Cells[0].Value.ToString();
                //l_debug2.Text = dgvcomps.SelectedCells[0].Value.ToString();
                        //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                        //        Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                        //SqlConnection sqlcon = new SqlConnection(connection);
                        //sqlcon.Open();
                Program.ConnectDb connect1 = new Program.ConnectDb();
                connect1.assignConnect(Program.user_name, Program.pass_word);
                connect1.myConnection.Open();
                DataTable dtbl1 = new DataTable();
                string cmd1 = searchInStores + " where computer_id=" + dgvcomps.CurrentRow.Cells[0].Value.ToString();
                using (var command = new SqlCommand(cmd1, connect1.myConnection))
                    dtbl1.Load(command.ExecuteReader());
                dgvstores.DataSource = dtbl1;
                dgvstores.AllowUserToAddRows = false;
                
            }
        }
    }
}

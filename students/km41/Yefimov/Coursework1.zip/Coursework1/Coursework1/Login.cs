﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.InteropServices;
namespace Coursework1
{

    public partial class Login : Form
    {
        //public static bool isadmin = false;
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox3.Text.Trim().Length < 128 || textBox4.Text.Trim().Length < 128)
            {
                Program.user_name = textBox3.Text.Trim();
                Program.pass_word = textBox4.Text.Trim();

                Program.ConnectDb connect1 = new Program.ConnectDb();
                connect1.assignConnect(Program.user_name, Program.pass_word);
                try
                {
                    
                    //string connection = @"Data Source=" + Program.datasource + ";Initial Catalog=" +
                    //    Program.catalog + ";User ID =" + Program.user_name + ";Password=" + Program.pass_word;
                    //SqlConnection sqlcon = new SqlConnection(connection);
                    SqlCommand cmd = new SqlCommand("dbo.CheckUser", connect1.myConnection);
                    //command.CommandType = CommandType.StoredProcedure;
                    //sqlcon.Open();
                    //DataTable dt = new DataTable();
                    //dt.Load(command.ExecuteReader());
                    cmd.CommandType = CommandType.StoredProcedure;

                    // set up the parameters
                    cmd.Parameters.Add("@username", SqlDbType.NVarChar, 128);

                    // set parameter values
                    cmd.Parameters["@username"].Value = textBox3.Text.Trim();

                    // open connection and execute stored procedure
                    connect1.myConnection.Open();
                    cmd.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    dt.Load(cmd.ExecuteReader());
                    DataRow row1;
                    //bool isadm = false;
                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("User doesn't exist");
                        this.Close();
                    }
                    else
                    {
                        row1 = dt.Rows[0];
                        Program.isadmin = row1.Field<bool>(1);
                    }
                    if (Program.isadmin == true)
                    {
                        this.Hide();
                        Admin a = new Admin();
                        a.Show();
                    }
                    else
                    {
                        this.Hide();
                        Form1 f1 = new Form1();
                        f1.Show();
                    }
                    //Program.loginname = user_name;
                    //int contractID = Convert.ToInt32(cmd.Parameters["@NewId"].Value);
                    //string query = "Select * from Users Where username = '" + textBox3.Text.Trim() + "'and password = '" + textBox4.Text.Trim() + "'";
                    //SqlDataAdapter sqlDa = new SqlDataAdapter(query, sqlcon);
                    //DataTable dtbl = new DataTable();
                    //sqlDa.Fill(dtbl);
                    //DataRow row1;
                    //if (dtbl.Rows.Count == 1)
                    //{
                    //    row1 = dtbl.Rows[0];
                    //    //MessageBox.Show(Convert.ToString(row1.Field<string>(1)));
                    //    if (row1.Field<string>(1) == "user3")
                    //    {
                    //        Form2 objFromMain1 = new Form2();
                    //        this.Hide();
                    //        objFromMain1.Show();
                    //    }
                    //    else
                    //    {
                    //        Form1 objFromMain = new Form1();
                    //        this.Hide();
                    //        objFromMain.Show();
                    //    }
                    //}
                    //else
                    //    MessageBox.Show("Check username and password");
                }
                catch (Exception ex)
                {
                    
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    connect1.myConnection.Dispose();
                }
            }
            else
                MessageBox.Show("Error: at least one of input values is too long");
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Program.user_name = textBox3.Text.Trim();
            //string connection = @"Data Source=" + inif.Read("db", "DataSource") + ";Initial Catalog=" + inif.Read("db", "InitialCatalog") + ";User ID =compadmin;Password=123";
            Program.pass_word = textBox4.Text.Trim();
            Hide();
            var regis = new Registration();
            regis.Closed += (s, args) => Close();
            Registration reg = new Registration();
            reg.Show();
        }
    }
    
}
